
import React from 'react';

export const Logo: React.FC<{ size?: number, className?: string }> = ({ size = 48, className = "" }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F5D76E" />
          <stop offset="50%" stopColor="#D4A54A" />
          <stop offset="100%" stopColor="#8C6A28" />
        </linearGradient>
      </defs>
      
      {/* The "R" Shape */}
      {/* Vertical Stem & Top Bar & Diagonal Leg */}
      <path 
        d="M15 80 V 25 H 40 C 52 25 55 35 52 45 C 50 50 45 52 40 52 H 30 M 42 52 L 55 80" 
        stroke="url(#goldGradient)" 
        strokeWidth="10" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      />

      {/* The Brain Shape (Right Side) */}
      <g transform="translate(60, 20) scale(0.6)">
         {/* Brain Outline/Lobes */}
         <path 
           d="M10 50 C 10 20 25 0 50 0 C 75 0 90 20 90 50 C 90 80 75 100 50 100 C 35 100 10 90 10 50 Z" 
           fill="#D4A54A"
           fillOpacity="0.2"
         />
         {/* Convolutions */}
         <path 
            d="M50 10 C 65 10 75 25 70 40 C 65 55 50 45 40 55 C 30 65 20 50 30 30 C 35 15 45 10 50 10"
            stroke="url(#goldGradient)"
            strokeWidth="6"
            strokeLinecap="round"
            fill="none"
         />
         <path 
            d="M70 40 C 80 45 85 60 75 80 C 65 100 45 90 40 80"
            stroke="url(#goldGradient)"
            strokeWidth="6"
            strokeLinecap="round"
             fill="none"
         />
         <path 
            d="M30 30 C 15 40 10 60 25 80 C 35 90 40 80 45 75"
            stroke="url(#goldGradient)"
            strokeWidth="6"
            strokeLinecap="round"
             fill="none"
         />
      </g>
    </svg>
  );
};
